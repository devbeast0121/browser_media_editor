/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_imageprocessor_free: (a: number, b: number) => void;
export const imageprocessor_new: (a: number, b: number) => number;
export const imageprocessor_apply_blur: (a: number, b: number, c: number, d: any, e: number) => void;
export const imageprocessor_apply_brightness: (a: number, b: number, c: number, d: any, e: number) => void;
export const imageprocessor_apply_contrast: (a: number, b: number, c: number, d: any, e: number) => void;
export const imageprocessor_apply_temperature: (a: number, b: number, c: number, d: any, e: number) => void;
export const imageprocessor_apply_effects_batch: (a: number, b: number, c: number, d: any, e: number, f: number, g: number, h: number) => void;
export const benchmark_processing: (a: number, b: number, c: number) => number;
export const __wbindgen_export_0: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_start: () => void;
